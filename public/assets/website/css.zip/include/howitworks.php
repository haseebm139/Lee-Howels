<div class="container-fluid howitworks">
		<div class="container howitworkscontainer">
			<div class="row">
				<h5 class="pt-5"><span style="color: #E7232B;" class="header">Our</span> <span class="product">Product</span></h5>

				<div class="col-md-4">
					<div class="sec2parentdiv">
						<div class="sec2row2col">
							<div>
								<img src="images/1.png"  alt="" class="img-fluid" />
							 </div>
							 <div style="margin-left:10px">
								<h5>CREATE AN ACCOUNT</h5>
								<span id="span"
								   >Sign up to an iDiet account through our webiste or mobile app</span
								   >
							 </div>
						</div>
					</div>



					<div class="sec2parentdiv formargin">
						<div class="sec2row2col">
							<div>
								<img src="images/3.png"  alt="" class="img-fluid" />
							 </div>
							 <div style="margin-left:10px">
								<h5>PICK YOUR PLAN</h5>
								<span id="span"
								   >Sign up to an iDiet account through our webiste or mobile app</span
								   >
							 </div>
						</div>
					</div>

				</div>

				<div class="col-md-4">
					
					<div class="sec2parentdiv formargin">
						<div class="sec2row2col">
							<div>
								<img src="images/2.png"  alt="" class="img-fluid" />
							 </div>
							 <div style="margin-left:10px">
								<h5>PICK YOUR PLAN</h5>
								<span id="span"
								   >Sign up to an iDiet account through our webiste or mobile app</span
								   >
							 </div>
						</div>
					</div>

					<div class="sec2parentdiv formargin">
						<div class="sec2row2col">
							<div>
								<img src="images/4.png"  alt="" class="img-fluid" />
							 </div>
							 <div style="margin-left:10px">
								<h5>PICK YOUR PLAN</h5>
								<span id="span"
								   >Sign up to an iDiet account through our webiste or mobile app</span
								   >
							 </div>
						</div>
					</div>

				</div>






				<div class="col-md-4">
					<img src="images/imghowitsworks.png" class="img-fluid">
				</div>
			</div>
		</div>

		<img src="images/vector61.png" class="img-fluid" id="forabsolute">
	</div>