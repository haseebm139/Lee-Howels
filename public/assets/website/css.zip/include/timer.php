<div class="container-fluid timer">
    <div class="container">
        <div class="row p-3">
         
            <div class="col-md-3" id="pad">
                 <div class="number-card">
                    <h3 class="num" data-val="377K+">377K+</h3>
                    <h4 class="numdet">Total Products</h4>
                </div>
            </div>


            <div class="col-md-3" id="pad">
                <div class="number-card">
                    <h3 class="num" data-val="500K+">500+</h3>
                    <h4 class="numdet">Active Clients</h4>
                </div>
            </div>

            <div class="col-md-3" id="pad">
                 <div class="number-card">
                    <h3 class="num" data-val="100K+">100K+</h3>
                    <h4 class="numdet">Satisfied Clients</h4>
                </div>
            </div>
            <div class="col-md-3" id="pad">

                <div class="number-card">
                    <h3 class="num" data-val="100k">100K+</h3>
                    <h4 class="numdet">Activate Products</h4>
                </div>
             </div>
             </div>
       
    </div>
    </div>