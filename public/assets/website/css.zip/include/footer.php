<!-- <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
       
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
	  <div class="container cart pb-1">
		<div class="card">
			<div class="container-fliud">
				<div class="wrapper row">
					<div class="preview col-md-6">
						
						<div class="preview-pic tab-content">
						  <div class="tab-pane active" id="pic-1"><img src="http://placekitten.com/400/252" /></div>
						  <div class="tab-pane" id="pic-2"><img src="http://placekitten.com/400/252" /></div>
						  <div class="tab-pane" id="pic-3"><img src="http://placekitten.com/400/252" /></div>
						  <div class="tab-pane" id="pic-4"><img src="http://placekitten.com/400/252" /></div>
						  <div class="tab-pane" id="pic-5"><img src="http://placekitten.com/400/252" /></div>
						</div>
						<ul class="preview-thumbnail nav nav-tabs">
						  <li class="active"><a data-target="#pic-1" data-toggle="tab"><img src="http://placekitten.com/200/126" /></a></li>
						  <li><a data-target="#pic-2" data-toggle="tab"><img src="http://placekitten.com/200/126" /></a></li>
						  <li><a data-target="#pic-3" data-toggle="tab"><img src="http://placekitten.com/200/126" /></a></li>
						  <li><a data-target="#pic-4" data-toggle="tab"><img src="http://placekitten.com/200/126" /></a></li>
						  <li><a data-target="#pic-5" data-toggle="tab"><img src="http://placekitten.com/200/126" /></a></li>
						</ul>
						
					</div>
					<div class="details col-md-6 ">
						<h3 class="product-title">Chinese Cabbage <span class="badge badge-secondary">In Stock</span></h3>
						<div class="rating">
							<div class="stars">
							
								<span class="sale-price"> <del> $48.00 </del> </span> 
								<span class="sale-retal">  $17.28  </span>
								<span class="badge badge-danger ml-3">64% Off</span>

								<hr>

							</div>

							<div class="stars pt-3">
								<div class="forflex">
								<div>
								<span class="brand">Brand :</span>
								<span class="ml-3 mr-3"><img src="images/brand.png" class="img-fluid"> </span>
								</div>

								<div>
								<span class="brand">Share Item :</span>
								<i class="fa-brands fa-square-x-twitter" style="font-size:25px"></i>
								<i class="fa-brands fa-facebook" style="font-size:25px"></i>
								<i class="fa-brands fa-pinterest" style="font-size:25px"></i>
								<i class="fa-brands fa-square-instagram mr-5" style="font-size:25px"></i>
								</div>
							</div>
							</div>
						</div>
						<p class="product-description">Suspendisse quos? Tempus cras iure temporibus? Eu laudantium cubilia sem sem! Repudiandae et! Massa . <a href="#" style="color:red;font-weight:600">Read More</a></p>
						
						<div class="action">
						<i class="fa-solid fa-circle-minus fa-2xl"></i>
						<span> 5 </span>
						<i class="fa-solid fa-circle-plus fa-2xl"></i>
							<button class="add-to-cart btn btn-default ml-3" type="button">Add to Cart <i class="fa-solid fa-cart-shopping fa-2xl"></i></button>
							<button class="like btn btn-default" type="button"><span class="fa fa-heart fa-2xl"></span></button>

							<p class="tag "> <strong> Category : </strong> Vegetables </p>
							<p class="tag " > <strong> Tag : </strong> Vegetables  Healthy Chinese Cabbage Green Cabbage </p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
      </div>
     
    </div>
  </div>
</div> -->


<div class="container-fluid footer">
		<div class="container footer">
			<div class="row">
				<div class="col-md-3">
					<div class="sec2parentdiv">
						<div class="sec2row2col">
							<div>
								<i class="fa-solid fa-headphones fa-2xl"style="color: white;"></i>
								
							 </div>
							 <div style="margin-left:10px">
								<h6 class="text-white">Call Us 24/7</h6>
								<span id="span" class="text-white"
								   >(1800)-88-66-991</span
								   >
							 </div>
						</div>
				</div>
				</div>
			
			<div class="col-md-3 pt-4">
					<h6 class="text-white">Follow Us</h6>
					<i class="fa-brands fa-facebook fa-xl" style="color: white;"></i>
					<i class="fa-brands fa-youtube  fa-xl" style="color: white;"></i>
					<i class="fa-brands fa-instagram fa-xl" style="color: white;"></i>
			</div>
			
			<div class="col-md-2">

			</div>

			<div class="col-md-4 pt-5 ">
				<img src="images/payment.png" class="img-fluid " >
			</div>
			
		</div>

		<div class="row mt-5">
			<hr style="color:white">
		</div>

		<div class="row pt-5">
			<div class="col-md-4 col-lg-3">
				<img src="images/footerlogo.png" class="img-fluid logofooter" >
			</div>

			<div class="col-md-4 col-lg-2">
				<h5 class="text-white mb-3">Quick links</h5>
				<ul class="list-unstyled ">
					<li><a href="#" style="color: #ADADAD;">About us</a></li>
					<li><a href="#" style="color: #ADADAD;">Blog</a></li>
					<li><a href="#" style="color: #ADADAD;">Check out</a></li>
					<li><a href="#" style="color: #ADADAD;">Contact</a></li>
					<li><a href="#" style="color: #ADADAD;">Service</a></li>
				</ul>
			</div>


			<div class="col-md-4 col-lg-2">
				<h5 class="text-white mb-3">MY ACCOUNT</h5>
				<ul class="list-unstyled ">
					<li><a href="#" style="color: #ADADAD;">My Account</a></li>
					<li><a href="#" style="color: #ADADAD;">Contact</a></li>
					<li><a href="#" style="color: #ADADAD;">Shopping cart</a></li>
					<li><a href="#" style="color: #ADADAD;">Shop</a></li>
					<li><a href="#" style="color: #ADADAD;">Service</a></li>
				</ul>
			</div>


			<div class="col-md-4 col-lg-2">
				<h5 class="text-white mb-3">CATEGORIES</h5>
				<ul class="list-unstyled ">
					<li><a href="#" style="color: #ADADAD;">Fruits & Vegetables</a></li>
					<li><a href="#" style="color: #ADADAD;">Dairy Products</a></li>
					<li><a href="#" style="color: #ADADAD;">Package Foods</a></li>
					<li><a href="#" style="color: #ADADAD;">Beverage</a></li>
					<li><a href="#" style="color: #ADADAD;">Health & Wellness</a></li>
				</ul>
			</div>


			<div class="col-md-6 col-lg-3">
				<h5 class="text-white mb-3">CATEGORIES</h5>
				<p style="color: #ADADAD; font-size: 14px;">Sign up and get a voucher of worth $250.00</p>
				<div class="signup_form">                           
					<form action="#" class="subscribe">
						<input type="text" class="subscribe__input" placeholder="Enter Email Address">
						<button type="button" class="subscribe__btn"><i class="fas fa-paper-plane"></i></button>
					</form>
				</div>
			</div>
			</div>

			
		<div class="row mt-5">
			<hr style="color:white">
		</div>


		<div class="row">
			<p class="text-center" style="color: #F2F2F2;font-family: Jost;
			font-size: 15px;
			font-style: normal;
			font-weight: 400;
			line-height: normal;">Fit Geek ©Copyright 2023 All rights reserved.</p>
		</div>

		</div>
		</div>
	</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
	<script>
	


let valueDisplays = document.querySelectorAll(".num");
let interval =  3000;

valueDisplays.forEach((valueDisplay) => {
    let startValue = 0;
    let endValue = parseInt(valueDisplay.getAttribute("data-val"));
     
    let duration = Math.floor(interval / endValue);
     let counter = setInterval(function  ( ) {
     
        startValue +=1;
           
        if (endValue== 0) {
            startValue -= 1;
        }
        valueDisplay.textContent=startValue+"K+";
        if (startValue== endValue) {
            clearInterval(counter);
        }


     },duration,);
}) ;

	</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
		
        // Get the current page URL
        var url = window.location.href;

        // Get the navigation buttons
        var navButtons = document.querySelectorAll('.nav-link');
		var defaultActiveLink = document.querySelector('.navbar-nav a.nav-link[href="index.html"]');

        // Loop through each navigation button
        navButtons.forEach(function (button) {
            // Compare the button's href with the current page URL
            if (url.includes(button.firstElementChild.getAttribute('href'))) {
                // Add the 'active' class to the matching button
                button.classList.add('active');
            }
        });
    });
</script>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Get the current page URL
        var url = window.location.href;

        // Get the navigation links
        var navLinks = document.querySelectorAll('.nav-link');

        // Default active link (e.g., Home)
        var defaultActiveLink = document.querySelector('.navbar-nav a.nav-link[href="index.html"]');

        // Loop through each navigation link
        navLinks.forEach(function (link) {
            // Compare the link's href with the current page URL
            if (url.includes(link.getAttribute('href'))) {
                // Add the 'active' class to the matching link
                link.classList.add('active');
            }
        });

        // If no link is active (e.g., on a page without a corresponding link), set the default active link
        if (!document.querySelector('.navbar-nav a.nav-link.active') && defaultActiveLink) {
            defaultActiveLink.classList.add('active');
        }
    });
</script>